module.exports = {
    giphyApiKey: process.env.GIPHY_API_KEY || 'dc6zaTOxFJmzC',
    ownerNumber: process.env.OWNER_TELEGRAM || '@JUTTXHACKER77',
    botName: 'USMAN MD',
    ownerName: 'USMAN-TECH'
};
